<?php
// Tanpa argumen
function nama_bulan() {
	echo 'Agustus';
}
nama_bulan(); // Hasil Agustus

