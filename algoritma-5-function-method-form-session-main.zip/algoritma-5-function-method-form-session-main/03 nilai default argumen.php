<?php
function nama_bulan($bulan, $tahun = 2016) {
	echo $bulan . ' ' . $tahun;
}
nama_bulan('Januari'); // Hasil Januari 2016
echo "<hr>";
nama_bulan('Ahmadi'); // Hasil Januari 2016
