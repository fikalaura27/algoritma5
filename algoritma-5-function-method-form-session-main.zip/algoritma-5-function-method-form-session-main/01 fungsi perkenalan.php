<?php
// mmbuat fungsi
function perkenalan(){
  echo "Assalamulaikum, ";
  echo "Perkenalkan, nama kita Ahmadi<br/>";
  echo "Senang berkenalan dengan anda<br/>";
}
// memanggil fungsi yang sudah dibuat
perkenalan();

echo "<hr>";
// memanggilnya lagi
perkenalan();
?>

