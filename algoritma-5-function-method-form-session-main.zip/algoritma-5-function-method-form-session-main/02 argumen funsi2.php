<?php
// Tanpa argumen

// Contoh berikutnya kita definisikan argumen, sehingga kita dapat mencetak nama bulan sesuai dengan yang kita inginkan:
function nama_bulan($bulan) {
	echo $bulan;
}
nama_bulan('Januari'); // Hasil Januari

